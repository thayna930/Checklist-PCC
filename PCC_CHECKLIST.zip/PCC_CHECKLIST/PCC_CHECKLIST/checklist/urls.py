from django.urls import path
from . import views

urlpatterns = [
    path('', views.listar_checklists, name='listar_checklists'),
    path('ver/<int:id>/', views.ver_checklist, name='ver_checklist'),
    path('criar/', views.criar_checklist, name='criar_checklist'),
    path('editar/<int:id>/', views.editar_checklist, name='editar_checklist'),
    path('deletar/<int:id>/', views.deletar_checklist, name='deletar_checklist'),
]
