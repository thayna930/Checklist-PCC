from django.db import models
from categoria.models import CategoriasDosItens
from questao.models import Questao


class Checklist(models.Model):

    #relação - vide diagrama
    categoria = models.ForeignKey(CategoriasDosItens, on_delete=models.CASCADE)
    questao = models.ForeignKey(Questao, on_delete=models.CASCADE)
    
    def __str__(self):
        return str(self.questao)