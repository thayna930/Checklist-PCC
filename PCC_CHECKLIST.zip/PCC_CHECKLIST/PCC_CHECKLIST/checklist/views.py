from django.shortcuts import render, redirect, get_object_or_404
from .forms import ChecklistForm
from .models import Checklist
from rolepermissions.decorators import has_permission_decorator
from django.contrib import messages

@has_permission_decorator('criar_checklist')
def criar_checklist(request):
    form = ChecklistForm(request.POST or None)
    if request.method == "POST":
        if form.is_valid():
            form.save()
            messages.success(request, "Checklist criado")
            return redirect('listar_checklists')
        else:
            messages.error(request, "Erro ao criar Checklist")
            return redirect('criar_checklist')

    return render(request, 'checklist/criar.html', {'form': form})

@has_permission_decorator('editar_checklist')
def editar_checklist(request, id):
    checklist = get_object_or_404(Checklist, pk=id)
    form = ChecklistForm(request.POST or None, instance=checklist)
    if request.method == "POST":
        if form.is_valid():
            form.save()
            messages.success(request, "Checklist editado")
            return redirect('listar_checklists')
        else:
            messages.error(request, "Erro ao editar Checklist")
            return redirect('editar_checklist')
    return render(request, 'checklist/editar.html', {'form': form})

@has_permission_decorator('deletar_checklist')
def deletar_checklist(request, id):
    if Checklist.objects.filter(pk=id):
        checklist = get_object_or_404(Checklist, pk=id)
        checklist.delete()
        messages.success(request, "Checklist excluida")
    else:
        messages.error(request, "Checklist não existe")

    return redirect('listar_checklists')

@has_permission_decorator('listar_checklists')
def listar_checklists(request):
    checklists = Checklist.objects.all()
    return render(request, 'checklist/listar.html', {'checklists': checklists})

@has_permission_decorator('ver_checklist')
def ver_checklist(request, id):
    if Checklist.objects.filter(pk=id):
        checklist = get_object_or_404(Checklist, pk=id)
    else:
        messages.error(request, "Checklist não existe")
        return redirect('listar_checklists')
    return render(request, 'checklist/ver.html', {'checklist': checklist})