from django import forms
from .models import Checklist
from django.forms import ModelForm

class ChecklistForm(ModelForm):

    class Meta:
        model = Checklist
        fields = '__all__'