from django.http import HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from categoria.models import CategoriasDosItens
from checklist.models import Checklist
from empresa.models import Empresa
from itenschecklist.models import ItensDoChecklist
from usuarios.models import Usuario
from .forms import ItensDoChecklistForm
# from weasyprint import HTML
from django.template.loader import render_to_string
from rolepermissions.decorators import has_permission_decorator
from rolepermissions.checkers import has_role
from django.contrib import messages
from django.contrib.auth.decorators import login_required


@has_permission_decorator('criar_itenschecklist')
def criar_itenschecklist(request, id):
    categorias = CategoriasDosItens.objects.all()
    checklists = Checklist.objects.all()
    total_questions = checklists.count()
    empresa = Empresa.objects.get(id=id)
    if ItensDoChecklist.objects.filter(empresa=empresa, usuario=request.user):
        avaliado = True
    else:
        avaliado = False

    if request.method == 'POST':
        empresa = Empresa.objects.get(id=id)
        for checklist in checklists:
            response = request.POST.get(f'response-{checklist.id}')
            outro = request.POST.get(f'outro-{checklist.id}', '')
            
            ItensDoChecklist.objects.create(
                condicao=response,
                outro=outro if response == '4' else '',
                empresa=empresa,
                usuario=Usuario.objects.get(id=request.user.id),
                checklist=checklist
            )

        idempresa = int(empresa.id)

        return JsonResponse({'message': 'Você já respondeu o checklist para esta empresa.', 'idempresa':idempresa}, status=200)

    return render(request, 'itenschecklist/criar.html', {
        'categorias': categorias,
        'empresa': empresa,
        'total_questions': total_questions,
        'avaliado': avaliado
    })

@has_permission_decorator('editar_itenschecklist')
def editar_itenschecklist(request, id):
    itenschecklist = get_object_or_404(ItensDoChecklist, pk=id)
    form = ItensDoChecklistForm(request.POST or None, instance=itenschecklist)
    if request.method == "POST":
        if form.is_valid():
            form.save()
            messages.success(request, "Resposta editada")
            return redirect('listar_itenschecklists')
        
        else:
            messages.error(request, "Erro ao editar Resposta")
            return redirect('editar_itenschecklist')
    return render(request, 'itenschecklist/editar.html', {'form': form})

@has_permission_decorator('deletar_itenschecklist')
def deletar_itenschecklist(request, id):
    if ItensDoChecklist.objects.filter(pk=id):
        itenschecklist = get_object_or_404(ItensDoChecklist, pk=id)
        itenschecklist.delete()
        messages.success(request, "Resposta excluida")
    else:
        messages.error(request, "Resposta não existe")

    return redirect('listar_itenschecklists')

@has_permission_decorator('deletar_todos_meus_itenschecklist')
def deletar_todos_meus_itenschecklist(request, id):
    empresa = Empresa.objects.get(id=id)
    if has_role(request.user, 'admin'):
        try:
            itenschecklist = ItensDoChecklist.objects.filter(empresa=empresa)
            itenschecklist.delete()
        except:
            messages.error(request, "Resposta não existe")
            return redirect('listar_itenschecklists')
    else:
        try:
            itenschecklist = ItensDoChecklist.objects.filter(empresa=empresa, usuario=request.user)
            itenschecklist.delete()
        except:
            messages.error(request, "Resposta não existe ou não é sua")
            return redirect('listar_itenschecklists')

    return redirect('listar_meus_itenschecklist', empresa.id)

@has_permission_decorator('listar_itenschecklist')
def listar_itenschecklist(request):
    itenschecklists = ItensDoChecklist.objects.all()
    return render(request, 'itenschecklist/listar.html', {'itenschecklists': itenschecklists})

@login_required
def listar_meus_itenschecklist(request, id):
    empresa = Empresa.objects.get(id=id)
    if has_role(request.user, 'admin'):
        try:
            titulo = f'Respostas da Empresa {empresa.razao_social}'
            itenschecklists = ItensDoChecklist.objects.filter(empresa=empresa)
        except:
            messages.error(request, "Resposta não existe ou não é sua")
            return redirect('listar_itenschecklists')
    else:
        try:
            titulo = f'Respostas da Empresa {empresa.razao_social} e do user {request.user.username}'
            itenschecklists = ItensDoChecklist.objects.filter(empresa=empresa, usuario=request.user)
        except:
            messages.error(request, "Resposta não existe ou não é sua")
            return redirect('listar_itenschecklists')
        
    return render(request, 'itenschecklist/listar.html', {'itenschecklists': itenschecklists, 'meu': True, 'empresa': empresa, 'titulo':titulo})

@has_permission_decorator('ver_itenschecklist')
def ver_itenschecklist(request, id):
    if ItensDoChecklist.objects.filter(pk=id):
        itenschecklist = get_object_or_404(ItensDoChecklist, pk=id)
    else:
        messages.error(request, "Resposta não existe")
        return redirect('listar_itenschecklists')
    
    return render(request, 'itenschecklist/ver.html', {'itenschecklist': itenschecklist})

@has_permission_decorator('gerar_relatorio')
def gerar_relatorio(request):
    empresaid = request.GET.get('empresaid')
    empresa = Empresa.objects.get(id=empresaid)
    if has_role(request.user, 'admin'):
        itenschecklists = ItensDoChecklist.objects.filter(empresa=empresa)
        itens_por_usuario = {}
        for item in itenschecklists:
            usuario_id = item.usuario.id
            if usuario_id not in itens_por_usuario:
                itens_por_usuario[usuario_id] = {
                    'usuario': item.usuario,
                    'itens': []
                }
            itens_por_usuario[usuario_id]['itens'].append(item)
        
        context = {
            'empresa': empresa,
            'itens_por_usuario': itens_por_usuario,
        }
    else:
        itenschecklists = ItensDoChecklist.objects.filter(empresa=empresa, usuario=request.user)
        context = {
            'empresa': empresa,
            'itens_por_usuario': {
                request.user.id: {
                    'usuario': request.user,
                    'itens': itenschecklists
                }
            },
        }

    return render(request, 'itenschecklist/pdf.html', context)