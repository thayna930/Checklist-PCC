from django.urls import path
from . import views

urlpatterns = [
    path('', views.listar_itenschecklist, name='listar_itenschecklists'),
    path('minhas/<int:id>/', views.listar_meus_itenschecklist, name='listar_meus_itenschecklist'),
    path('ver/<int:id>/', views.ver_itenschecklist, name='ver_itenschecklist'),
    path('criar/<int:id>/', views.criar_itenschecklist, name='criar_itenschecklist'),
    path('editar/<int:id>/', views.editar_itenschecklist, name='editar_itenschecklist'),
    path('deletar/<int:id>/', views.deletar_itenschecklist, name='deletar_itenschecklist'),
    path('minhas/deletar/<int:id>/', views.deletar_todos_meus_itenschecklist, name='deletar_todos_meus_itenschecklist'),

    path('relatorio/', views.gerar_relatorio, name='gerar_relatorio'),
]
