from django import forms
from .models import ItensDoChecklist

class ItensDoChecklistForm(forms.ModelForm):
    class Meta:
        model = ItensDoChecklist
        fields = '__all__'