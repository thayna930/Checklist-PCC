from django.db import models
from categoria.models import CategoriasDosItens
from empresa.models import Empresa
from usuarios.models import Usuario
from checklist.models import Checklist

class ItensDoChecklist(models.Model):
    CONDICAO_CHOICES = [
        (1, 'Muito Acessível'),
        (2, 'Parcialmente Acessível'),
        (3, 'Nada Acessível'),
        (4, 'Outro')
    ]
    condicao = models.IntegerField(choices=CONDICAO_CHOICES)
    outro = models.CharField(max_length=50, blank=True, null=True)
    #relações - vide diagrama
    usuario = models.ForeignKey(Usuario, on_delete=models.CASCADE)
    empresa = models.ForeignKey(Empresa, on_delete=models.CASCADE)
    checklist = models.ForeignKey(Checklist, on_delete=models.CASCADE)
    
    def __str__(self):
        return f'{self.get_condicao_display()} + {self.empresa}'