from django.contrib import admin
from .models import ItensDoChecklist

admin.site.register(ItensDoChecklist)