from django import forms
from .models import CategoriasDosItens
from django.forms import ModelForm

class CategoriasDosItensForm(ModelForm):

    class Meta:
        model = CategoriasDosItens
        fields = '__all__'