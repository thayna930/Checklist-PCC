from django.shortcuts import render, redirect, get_object_or_404
from .forms import CategoriasDosItensForm
from .models import CategoriasDosItens
from rolepermissions.decorators import has_permission_decorator
from django.contrib import messages

@has_permission_decorator('criar_categoria')
def criar_categoria(request):
    form = CategoriasDosItensForm(request.POST or None)
    if request.method == "POST":
        if form.is_valid():
            form.save()
            messages.success(request, "Categoria criada")
            return redirect('listar_categorias')
        else:
            messages.error(request, "Erro ao criar categoria")
            return redirect('criar_categoria')

    return render(request, 'categoria/criar.html', {'form': form})

@has_permission_decorator('editar_categoria')
def editar_categoria(request, id):
    categoria = get_object_or_404(CategoriasDosItens, pk=id)
    form = CategoriasDosItensForm(request.POST or None, instance=categoria)
    if request.method == "POST":
        if form.is_valid():
            form.save()
            messages.success(request, "Categoria editada")
            return redirect('listar_categorias')
        else:
            messages.error(request, "Erro ao editar categoria")
            return redirect('editar_categoria')

    return render(request, 'categoria/editar.html', {'form': form})

@has_permission_decorator('deletar_categoria')
def deletar_categoria(request, id):
    if CategoriasDosItens.objects.filter(pk=id):
        categoria = get_object_or_404(CategoriasDosItens, pk=id)
        categoria.delete()
        messages.success(request, "Categoria excluida")
    else:
        messages.error(request, "Categoria não existe")

    return redirect('listar_categorias')

@has_permission_decorator('listar_categorias')
def listar_categorias(request):
    categorias = CategoriasDosItens.objects.all()
    return render(request, 'categoria/listar.html', {'categorias': categorias})

@has_permission_decorator('ver_categoria')
def ver_categoria(request, id):
    if CategoriasDosItens.objects.filter(pk=id):
        categoria = get_object_or_404(CategoriasDosItens, pk=id)
    else:
        messages.error(request, "Categoria não existe")
        return redirect('listar_categorias')
    return render(request, 'categoria/ver.html', {'categoria': categoria})