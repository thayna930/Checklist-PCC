from django.urls import path
from . import views

urlpatterns = [
    path('', views.listar_categorias, name='listar_categorias'),
    path('ver/<int:id>/', views.ver_categoria, name='ver_categoria'),
    path('criar/', views.criar_categoria, name='criar_categoria'),
    path('editar/<int:id>/', views.editar_categoria, name='editar_categoria'),
    path('deletar/<int:id>/', views.deletar_categoria, name='deletar_categoria'),
]
