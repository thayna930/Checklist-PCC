from rolepermissions.roles import AbstractUserRole

class Usuario(AbstractUserRole):
    available_permissions = {
        'listar_itenschecklist': True,
        'listar_meus_itenschecklist': True,
        'listar_itenschecklist_empresa': True,
        'ver_itenschecklist': True,
        'criar_itenschecklist': True,
        'editar_itenschecklist': True,
        'deletar_itenschecklist': True,
        'deletar_todos_meus_itenschecklist': True,
        'gerar_relatorio': True,

        'listar_empresas': True,
        'ver_empresa': True,
    }

class Admin(AbstractUserRole):
    available_permissions = {
        'listar_itenschecklist': True,
        'listar_meus_itenschecklist': True,
        'listar_itenschecklist_empresa': True,
        'ver_itenschecklist': True,
        'deletar_itenschecklist': True,
        'deletar_todos_meus_itenschecklist': True,
        'gerar_relatorio': True,

        'listar_categorias':True,
        'ver_categoria':True,
        'criar_categoria':True,
        'editar_categoria':True,
        'deletar_categoria':True,

        'listar_checklists': True,
        'ver_checklist': True,
        'criar_checklist': True,
        'editar_checklist': True,
        'deletar_checklist': True,

        'listar_empresas': True,
        'criar_empresa': True,
        'editar_empresa': True,
        'ver_empresa': True,
        'deletar_empresa': True,

        'listar_questao': True,
        'criar_questao': True,
        'editar_questao': True,
        'deletar_questao': True,
    }


