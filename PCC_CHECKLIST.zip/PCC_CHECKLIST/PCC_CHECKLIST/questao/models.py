from django.db import models

class Questao(models.Model):
    questao = models.TextField()
    
    def __str__(self):
        return self.questao