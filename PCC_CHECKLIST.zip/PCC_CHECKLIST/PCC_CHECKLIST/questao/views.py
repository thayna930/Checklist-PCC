from django.shortcuts import get_object_or_404, redirect, render
from questao.models import Questao
from .forms import QuestaoForm
from rolepermissions.decorators import has_permission_decorator
from django.contrib import messages
from rolepermissions.roles import assign_role


@has_permission_decorator('listar_questao')
def listar_questao(request):
    questoes = Questao.objects.all()
    return render(request, 'questao/listar.html', {'questoes': questoes})

@has_permission_decorator('criar_questao')
def criar_questao(request):
    form = QuestaoForm()
    if request.method == "POST":
        form = QuestaoForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Questão criada")
            return redirect('listar_questao')
        else:
            messages.error(request, "Erro ao criar questão")
            return redirect('criar_questao')

    return render(request, 'categoria/criar.html', {'form': form})

@has_permission_decorator('editar_questao')
def editar_questao(request, id):
    questao = get_object_or_404(Questao, pk=id)
    form = QuestaoForm(instance=questao)

    if request.method == "POST":
        form = QuestaoForm(request.POST, instance=questao)
        if form.is_valid():
            form.save()
            messages.success(request, "Questão editada")
            return redirect('listar_questao')
        else:
            messages.error(request, "Erro ao editar questão")
            return redirect('editar_questao')

    return render(request, 'questao/editar.html', {'form': form})

@has_permission_decorator('deletar_questao')
def deletar_questao(request, id):
    if Questao.objects.filter(pk=id):
        questao = get_object_or_404(Questao, pk=id)
        questao.delete()
        messages.success(request, "Questão excluida")
    else:
        messages.error(request, "Questão não existe")

    return redirect('listar_questao')