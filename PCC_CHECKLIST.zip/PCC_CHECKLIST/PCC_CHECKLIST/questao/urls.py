from django.urls import path
from . import views

urlpatterns = [
    path('', views.listar_questao, name='listar_questao'),
    path('criar/', views.criar_questao, name='criar_questao'),
    path('editar/<int:id>/', views.editar_questao, name='editar_questao'),
    path('deletar/<int:id>/', views.deletar_questao, name='deletar_questao'),
]
