from django import forms
from .models import Empresa
from django.forms import ModelForm

class EmpresaForm(ModelForm):
    fundada_em = forms.DateField(
        widget=forms.DateInput(format='%Y-%m-%d',attrs={'type': 'date'})
    )
    class Meta:
        model = Empresa
        fields = '__all__'