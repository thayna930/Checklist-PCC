from django.db import models

class Empresa(models.Model):
    razao_social = models.CharField(max_length=255)
    nome_fantasia = models.CharField(max_length=255)
    cnpj = models.CharField(max_length=18, unique=True)
    ramo_empresa = models.CharField(max_length=255)
    endereco = models.CharField(max_length=255)
    estado = models.CharField(max_length=2)
    cidade = models.CharField(max_length=100)
    telefone = models.CharField(max_length=15)
    email = models.EmailField()
    fundada_em = models.DateField(auto_now=False)
    site = models.URLField()
    #relação "Gerências Empresas" - vide diagrama de classes
    gerente = models.ForeignKey("usuarios.Usuario", on_delete=models.DO_NOTHING)


    def __str__(self):
        return self.razao_social