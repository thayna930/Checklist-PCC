from django.urls import path
from . import views

urlpatterns = [
    path('', views.listar_empresas, name='listar_empresas'),
    path('ver/<int:id>/', views.ver_empresa, name='ver_empresa'),
    path('criar/', views.criar_empresa, name='criar_empresa'),
    path('editar/<int:id>/', views.editar_empresa, name='editar_empresa'),
    path('deletar/<int:id>/', views.deletar_empresa, name='deletar_empresa'),
]
