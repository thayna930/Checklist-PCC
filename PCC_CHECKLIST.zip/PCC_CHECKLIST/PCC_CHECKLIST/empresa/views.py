from django.shortcuts import render, redirect, get_object_or_404
from rolepermissions.decorators import has_permission_decorator
from django.contrib import messages
from itenschecklist.models import ItensDoChecklist
from .forms import EmpresaForm
from .models import Empresa

@has_permission_decorator('criar_empresa')
def criar_empresa(request):
    form = EmpresaForm(request.POST or None)
    if request.method == "POST":
        if form.is_valid():
            form.save()
            messages.success(request, "Empresa criada")
            return redirect('listar_empresas')
        else:
            messages.error(request, "Erro ao criar Empresa")
            return redirect('criar_empresa')
    return render(request, 'empresa/criar.html', {'form': form})

@has_permission_decorator('editar_empresa')
def editar_empresa(request, id):
    empresa = get_object_or_404(Empresa, pk=id)
    form = EmpresaForm(request.POST or None, instance=empresa)
    if request.method == "POST":
        if form.is_valid():
            form.save()
            messages.success(request, "Empresa editada")
            return redirect('listar_empresas')
        else:
            messages.error(request, "Erro ao editar Empresa")
            return redirect('editar_empresa')

    return render(request, 'empresa/editar.html', {'form': form})

@has_permission_decorator('deletar_empresa')
def deletar_empresa(request, id):
    if Empresa.objects.filter(pk=id):
        empresa = get_object_or_404(Empresa, pk=id)
        empresa.delete()
        messages.success(request, "Empresa excluida")
    else:
        messages.error(request, "Empresa não existe")

    return redirect('listar_empresas')

@has_permission_decorator('listar_empresas')
def listar_empresas(request):
    empresas = Empresa.objects.all()
    return render(request, 'empresa/listar.html', {'empresas': empresas})

@has_permission_decorator('ver_empresa')
def ver_empresa(request, id):
    if Empresa.objects.filter(pk=id):
        empresa = get_object_or_404(Empresa, pk=id)
        avaliada = ItensDoChecklist.objects.filter(empresa=empresa, usuario=request.user)
    else:
        messages.error(request, "Empresa não existe")
        return redirect('listar_empresas')
    
    return render(request, 'empresa/ver.html', {'empresa': empresa, 'avaliada':avaliada})