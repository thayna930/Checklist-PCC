# admin.py
from django.contrib import admin
from .models import Empresa
from django.contrib.auth.admin import UserAdmin

class EmpresaAdmin(admin.ModelAdmin):
    list_display = ('razao_social', 'cnpj', 'ramo_empresa', 'cidade', 'estado', 'telefone', 'email', 'fundada_em')
    search_fields = ('razao_social', 'cnpj', 'cidade')
    list_filter = ('ramo_empresa', 'estado')

admin.site.register(Empresa, EmpresaAdmin)
