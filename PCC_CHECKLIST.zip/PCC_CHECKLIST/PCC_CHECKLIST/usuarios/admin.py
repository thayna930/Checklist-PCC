from django.contrib.auth import admin
from django.contrib import admin
from .models import Usuario
from django.contrib.auth.admin import UserAdmin
# Classe personalizada para a administração do modelo Usuario no painel administrativo.
class UsuarioAdmin(UserAdmin):
    # Adiciona novos campos ao formulário padrão do UserAdmin.
    fieldsets = UserAdmin.fieldsets + (
        (None, {'fields': ('data_nascimento', 'telefone', 'cpf')}),
    )

# Registra o modelo Usuario e a classe UsuarioAdmin no site administrativo do Django.
admin.site.register(Usuario, UsuarioAdmin)