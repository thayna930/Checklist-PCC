from django import forms
from .models import Usuario
from django.contrib.auth.forms import UserCreationForm, UserChangeForm
from rolepermissions.roles import assign_role

class UsuarioCreationForm(UserCreationForm):
    data_nascimento = forms.DateField(label='Data de Nascimento', widget=forms.DateInput(attrs={'type': 'date'}), required=False)

    class Meta(UserCreationForm.Meta):
        model = Usuario        
        fields = ('username', 'first_name', 'email', 'data_nascimento', 'telefone', 'cpf', 'is_superuser','password1', 'password2')

    def save(self, commit=True):
        user = super().save(commit=False)
        user.save()
        
        if user.is_superuser:
            user.is_superuser = True
            user.is_staff = True
            assign_role(user, 'admin')
        else:
            assign_role(user, 'usuario')
        
        if commit:
            user.save()
        
        return user
    

class UsuarioChangeForm(UserChangeForm):
    data_nascimento = forms.DateField(label='Data de Nascimento', widget=forms.DateInput(attrs={'type': 'date'}), required=False)

    class Meta(UserChangeForm.Meta):
        model = Usuario
        fields = ('first_name', 'email', 'data_nascimento', 'telefone', 'cpf', 'is_superuser')

    def save(self, commit=True):
        user = super().save(commit=False)

        if user.is_superuser:
            user.is_superuser = True
            user.is_staff = True
            assign_role(user, 'admin')
        else:
            assign_role(user, 'usuario')
        
        if commit:
            user.save()
        
        return user
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields.pop('password')
        if self.instance.pk:
            data_nascimento = self.instance.data_nascimento
            if data_nascimento:
                self.initial['data_nascimento'] = data_nascimento.strftime('%Y-%m-%d')
